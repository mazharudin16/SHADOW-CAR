# Neon Drift (Phase 1)
Native Android 3D drift game: Kotlin + OpenGL ES 3.0. Package com.neondrift.game, minSdk 26.
Build: open in Android Studio, or use the GitHub Actions workflow.
Controls: touch buttons / tilt / keyboard (WASD, SPACE=drift, SHIFT=nitro, C=cam, R=reset, ESC=garage) / gamepad.

## Owner Admin Panel
A local Owner button is overlaid at the top center. Password: `shadow modz`.
Available actions: add coins, unlock all cars, max upgrades, infinite nitro, God Mode (disable track collision), 5x drift points, 2x torque, change paint, and reset the local save.

Security note: this is an offline convenience lock. A password embedded in an APK can be extracted; do not reuse it for any real account or online service. For production multiplayer, validate admin permissions on a trusted server.
