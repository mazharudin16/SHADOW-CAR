package com.neondrift.game

import android.app.AlertDialog
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.text.InputType
import android.view.Gravity
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/** Local owner tools. This is a convenience lock, not server-grade security. */
object AdminPanel {
    private const val OWNER_PASSWORD = "shadow modz"

    fun showLogin(context: Context, game: Game) {
        val input = EditText(context).apply {
            hint = "Owner password"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setSingleLine(true)
        }
        AlertDialog.Builder(context)
            .setTitle("NEON DRIFT • OWNER LOGIN")
            .setMessage("Private admin access")
            .setView(input)
            .setNegativeButton("CANCEL", null)
            .setPositiveButton("UNLOCK", null)
            .create().also { dialog ->
                dialog.setOnShowListener {
                    dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                        if (input.text.toString() == OWNER_PASSWORD) {
                            dialog.dismiss(); showPanel(context, game)
                        } else {
                            input.error = "Incorrect password"
                        }
                    }
                }
                dialog.show()
            }
    }

    private fun showPanel(context: Context, game: Game) {
        val options = arrayOf(
            "Add 10,000 coins",
            "Add custom coins",
            "Unlock all cars",
            "Max all upgrades",
            "${if (game.adminInfiniteNitro) "Disable" else "Enable"} Infinite Nitro",
            "${if (game.adminGodMode) "Disable" else "Enable"} God Mode",
            "${if (game.adminFiveXDrift) "Disable" else "Enable"} 5x Drift Points",
            "${if (game.adminDoubleTorque) "Disable" else "Enable"} 2x Torque",
            "Change paint",
            "Reset game save"
        )
        AlertDialog.Builder(context)
            .setTitle("NEON DRIFT • OWNER PANEL")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> game.adminAddCoins(10_000)
                    1 -> customCoins(context, game)
                    2 -> confirm(context, "Unlock every car?", "UNLOCK") { game.adminUnlockAll() }
                    3 -> confirm(context, "Set every car upgrade to level 5?", "MAX OUT") { game.adminMaxUpgrades() }
                    4 -> game.adminToggle("nitro", !game.adminInfiniteNitro)
                    5 -> game.adminToggle("god", !game.adminGodMode)
                    6 -> game.adminToggle("drift", !game.adminFiveXDrift)
                    7 -> game.adminToggle("torque", !game.adminDoubleTorque)
                    8 -> choosePaint(context, game)
                    9 -> confirm(context, "This resets coins, cars, upgrades and settings. Continue?", "RESET SAVE") { game.adminResetSave() }
                }
            }
            .setNegativeButton("CLOSE", null)
            .show()
    }

    private fun customCoins(context: Context, game: Game) {
        val input = EditText(context).apply {
            hint = "Amount (1 - 2,000,000,000)"
            inputType = InputType.TYPE_CLASS_NUMBER
        }
        AlertDialog.Builder(context).setTitle("ADD COINS").setView(input)
            .setNegativeButton("CANCEL", null)
            .setPositiveButton("ADD", null).create().also { dialog ->
                dialog.setOnShowListener {
                    dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                        val amount = input.text.toString().toLongOrNull()
                        if (amount == null || amount !in 1..2_000_000_000L) input.error = "Enter a valid amount"
                        else { game.adminAddCoins(amount.toInt()); dialog.dismiss() }
                    }
                }
                dialog.show()
            }
    }

    private fun choosePaint(context: Context, game: Game) {
        val names = arrayOf("Red", "Blue", "Purple", "Green", "Orange", "White", "Black", "Pink")
        AlertDialog.Builder(context).setTitle("SELECT CAR PAINT")
            .setSingleChoiceItems(names, game.paintIdx) { dialog, which ->
                game.adminSetPaint(which); dialog.dismiss()
            }.setNegativeButton("CANCEL", null).show()
    }

    private fun confirm(context: Context, message: String, action: String, run: () -> Unit) {
        AlertDialog.Builder(context).setMessage(message)
            .setNegativeButton("CANCEL", null)
            .setPositiveButton(action) { _, _ -> run() }.show()
    }

    fun makeEntryButton(context: Context, onClick: () -> Unit): TextView = TextView(context).apply {
        text = "OWNER"
        setTextColor(Color.WHITE)
        textSize = 13f
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        setPadding(22, 12, 22, 12)
        setBackgroundColor(Color.rgb(145, 20, 130))
        alpha = 0.92f
        setOnClickListener { onClick() }
        contentDescription = "Open owner admin panel"
    }
}
