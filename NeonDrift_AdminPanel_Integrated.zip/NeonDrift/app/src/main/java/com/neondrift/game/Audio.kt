package com.neondrift.game

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlin.math.*

/** Synthesised engine + tyre squeal, no audio assets needed. */
class EngineAudio(private val g: Game) {
    private var track: AudioTrack? = null
    @Volatile private var running = false
    private var thread: Thread? = null
    private val sr = 22050

    fun start() {
        if (running) return
        try {
            val min = AudioTrack.getMinBufferSize(sr, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val t = AudioTrack.Builder()
                .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                .setAudioFormat(AudioFormat.Builder().setSampleRate(sr).setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                .setBufferSizeInBytes(max(min, 4096))
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()
            track = t
            running = true
            t.play()
            thread = Thread {
                val buf = ShortArray(512)
                var ph = 0.0; var ph2 = 0.0; var sq = 0.0
                var seed = 12345
                var rpmS = 1000.0; var volS = 0.0; var sqS = 0.0
                while (running) {
                    val c = g.car
                    val active = g.state == 1
                    val rpmT = if (active) c.rpm.toDouble() else 1000.0
                    val load = if (active) (g.steerShown * 0.0 + (if (g.touchGas || g.keyGas || g.padGas > 0.1f) 1.0 else 0.25)) else 0.2
                    val sqT = if (active) max(c.rearSlip, c.frontSlip * 0.7f).toDouble() else 0.0
                    val nit = if (g.nitroActive) 1.0 else 0.0
                    for (i in buf.indices) {
                        rpmS += (rpmT - rpmS) * 0.0004
                        volS += ((0.25 + 0.4 * load) - volS) * 0.0005
                        sqS += (sqT - sqS) * 0.0008
                        val f = rpmS / 60.0 * 2.0
                        ph += 2.0 * PI * f / sr; if (ph > 2 * PI) ph -= 2 * PI
                        ph2 += 2.0 * PI * (f * 0.5) / sr; if (ph2 > 2 * PI) ph2 -= 2 * PI
                        var s = 0.0
                        for (k in 1..7) s += sin(ph * k) / k * (if (k % 2 == 0) 0.8 else 1.0)
                        s += sin(ph2) * 0.6 + sin(ph * 0.5) * 0.4
                        seed = seed * 1103515245 + 12345
                        val n = ((seed shr 16) and 0x7fff) / 16384.0 - 1.0
                        s = s * 0.28 + n * (0.05 + 0.10 * load) + nit * n * 0.12
                        sq += 2.0 * PI * (1700.0 + 500.0 * sqS) / sr; if (sq > 2 * PI) sq -= 2 * PI
                        val squeal = if (sqS > 0.3) (sin(sq) * 0.5 + n * 0.5) * (sqS - 0.3) * 0.5 else 0.0
                        val out = (s * volS + squeal) * 0.7
                        buf[i] = (out.coerceIn(-1.0, 1.0) * 14000).toInt().toShort()
                    }
                    t.write(buf, 0, buf.size)
                }
            }.also { it.isDaemon = true; it.start() }
        } catch (e: Exception) { running = false }
    }

    fun stop() {
        running = false
        try { thread?.join(300) } catch (_: Exception) {}
        try { track?.stop(); track?.release() } catch (_: Exception) {}
        track = null; thread = null
    }
}
