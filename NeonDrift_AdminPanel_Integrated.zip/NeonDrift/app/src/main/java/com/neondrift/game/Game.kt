package com.neondrift.game

import android.content.Context
import kotlin.math.*
import kotlin.random.Random

class CarSpec(val name: String, val price: Int, val mass: Float, val torque: Float,
              val muF: Float, val muR: Float, val style: Int, val desc: String)

val CARS = listOf(
    CarSpec("HACHI RS", 0, 1250f, 410f, 1.15f, 1.08f, 0, "Balanced RWD coupe"),
    CarSpec("MUSTANG V8", 25000, 1550f, 570f, 1.05f, 1.02f, 1, "Brutal power, huge slides"),
    CarSpec("TUNER Z", 60000, 1150f, 480f, 1.22f, 1.14f, 2, "Light and razor sharp")
)
val PAINTS = listOf(
    floatArrayOf(0.85f, 0.07f, 0.10f), floatArrayOf(0.08f, 0.30f, 0.95f), floatArrayOf(0.55f, 0.15f, 0.95f),
    floatArrayOf(0.30f, 0.90f, 0.15f), floatArrayOf(1.00f, 0.42f, 0.04f), floatArrayOf(0.90f, 0.92f, 0.96f),
    floatArrayOf(0.05f, 0.05f, 0.06f), floatArrayOf(1.00f, 0.20f, 0.60f)
)
val UPG_NAMES = arrayOf("ENGINE", "TIRES", "TURBO")
val UPG_COST = intArrayOf(2000, 1500, 1800)

class Store(c: Context) {
    private val p = c.getSharedPreferences("neondrift", Context.MODE_PRIVATE)
    fun i(k: String, d: Int) = p.getInt(k, d)
    fun s(k: String, v: Int) { p.edit().putInt(k, v).apply() }
    fun editor() = p.edit()
}

/** Particles (smoke / flames) + skid mark ring buffer. */
class Fx {
    val max = 360
    val p = FloatArray(max * 10) // x y z vx vy vz age life size kind
    var cnt = 0
    private var rr = 0
    fun emit(x: Float, y: Float, z: Float, vx: Float, vy: Float, vz: Float, life: Float, size: Float, kind: Float) {
        val i = if (cnt < max) cnt++ else (rr++ % max)
        val o = i * 10
        p[o] = x; p[o + 1] = y; p[o + 2] = z; p[o + 3] = vx; p[o + 4] = vy; p[o + 5] = vz
        p[o + 6] = 0f; p[o + 7] = life; p[o + 8] = size; p[o + 9] = kind
    }
    fun update(dt: Float) {
        var i = 0
        while (i < cnt) {
            val o = i * 10
            p[o + 6] += dt
            if (p[o + 6] > p[o + 7]) {
                val l = (cnt - 1) * 10
                for (k in 0 until 10) p[o + k] = p[l + k]
                cnt--
                continue
            }
            p[o] += p[o + 3] * dt; p[o + 1] += p[o + 4] * dt; p[o + 2] += p[o + 5] * dt
            if (p[o + 9] < 0.5f) { val d = 1f - 1.8f * dt; p[o + 3] *= d; p[o + 5] *= d; p[o + 4] += 0.5f * dt }
            i++
        }
    }

    // skid marks: 6 verts * 9 floats per segment
    val skMax = 1500
    val sk = FloatArray(skMax * 54)
    var skHead = 0
    var skCount = 0
    val prevX = FloatArray(4); val prevZ = FloatArray(4); val prevOk = BooleanArray(4)
    fun skid(w: Int, x: Float, z: Float, alpha: Float) {
        if (prevOk[w]) {
            val dx = x - prevX[w]; val dz = z - prevZ[w]
            val l = sqrt(dx * dx + dz * dz)
            if (l < 0.35f) return
            val px = -dz / l * 0.14f; val pz = dx / l * 0.14f
            val o = skHead * 54
            val y = 0.09f
            fun v(i: Int, vx: Float, vz: Float) {
                val q = o + i * 9
                sk[q] = vx; sk[q + 1] = y; sk[q + 2] = vz; sk[q + 3] = 10f; sk[q + 4] = 10f
                sk[q + 5] = 0.01f; sk[q + 6] = 0.01f; sk[q + 7] = 0.01f; sk[q + 8] = alpha
            }
            val ax = prevX[w] + px; val az = prevZ[w] + pz
            val bx = prevX[w] - px; val bz = prevZ[w] - pz
            val cx = x - px; val cz = z - pz
            val dxx = x + px; val dzz = z + pz
            v(0, ax, az); v(1, bx, bz); v(2, cx, cz); v(3, ax, az); v(4, cx, cz); v(5, dxx, dzz)
            skHead = (skHead + 1) % skMax
            if (skCount < skMax) skCount++
        }
        prevX[w] = x; prevZ[w] = z; prevOk[w] = true
    }
    fun skidEnd(w: Int) { prevOk[w] = false }
}

class Game(ctx: Context) {
    val store = Store(ctx)
    val world = World()
    val car = CarPhysics()
    val fx = Fx()

    // persistent
    var coins = store.i("coins", 5000)
    var carIdx = store.i("car", 0)
    var paintIdx = store.i("paint", 0)
    var owned = store.i("owned", 1)
    var tiltOn = store.i("tilt", 0) == 1
    var tiltInv = store.i("tiltinv", 0) == 1
    var best = store.i("best", 0)

    // Owner-only local admin switches
    @Volatile var adminInfiniteNitro = store.i("admin_nitro", 0) == 1
    @Volatile var adminGodMode = store.i("admin_god", 0) == 1
    @Volatile var adminFiveXDrift = store.i("admin_drift", 0) == 1
    @Volatile var adminDoubleTorque = store.i("admin_torque", 0) == 1

    @Volatile var carVersion = 0
    @Volatile var state = 0 // 0 garage, 1 driving
    var started = false
    var camMode = 0

    // inputs
    @Volatile var touchL = false
    @Volatile var touchR = false
    @Volatile var touchGas = false
    @Volatile var touchBrk = false
    @Volatile var touchHb = false
    @Volatile var touchNit = false
    @Volatile var keyL = false
    @Volatile var keyR = false
    @Volatile var keyGas = false
    @Volatile var keyBrk = false
    @Volatile var keyHb = false
    @Volatile var keyNit = false
    @Volatile var padSteer = 0f
    @Volatile var padGas = 0f
    @Volatile var padBrk = 0f
    @Volatile var tilt = 0f

    private var steerSm = 0f
    private var thrSm = 0f
    var steerShown = 0f

    // gameplay
    var nitro = 1f
    var nitroActive = false
    var driftPts = 0f
    var driftT = 0f
    var graceT = 0f
    var mult = 1
    var totalScore = 0
    var toast = ""
    var toastT = 0f
    var shake = 0f
    var time = 0f
    var braking = false
    var driftAngleDeg = 0f

    // camera
    var camX = 0f; var camY = 3f; var camZ = -10f
    var lookX = 0f; var lookY = 1f; var lookZ = 0f
    var fov = 60f
    private var camAng = 0f
    private var menuAng = 0.6f

    init {
        applySpec()
        toStart()
    }

    fun spec() = CARS[carIdx]
    fun upg(k: Int) = store.i("u${carIdx}_$k", 0)

    fun applySpec() {
        val s = spec()
        car.mass = s.mass
        car.torque = s.torque * (1f + 0.07f * upg(0)) * (if (adminDoubleTorque) 2f else 1f)
        car.muF = s.muF * (1f + 0.035f * upg(1))
        car.muR = s.muR * (1f + 0.035f * upg(1))
        car.nitroPower = 0.35f + 0.08f * upg(2)
    }

    private fun toStart() {
        car.place(world.tx[0], world.tz[0], world.startPsi(0))
        camAng = car.psi
    }

    fun toast(t: String) { toast = t; toastT = 2.2f }

    fun menuAction(id: Int) {
        when {
            id == 1 || id == 2 -> {
                carIdx = (carIdx + (if (id == 1) CARS.size - 1 else 1)) % CARS.size
                store.s("car", carIdx); applySpec(); carVersion++
            }
            id in 10..17 -> { paintIdx = id - 10; store.s("paint", paintIdx); carVersion++ }
            id in 20..22 -> {
                val k = id - 20; val lv = upg(k)
                val cost = (lv + 1) * UPG_COST[k]
                if (lv < 5 && coins >= cost) {
                    coins -= cost; store.s("coins", coins); store.s("u${carIdx}_$k", lv + 1); applySpec()
                }
            }
            id == 30 -> {
                if (owned and (1 shl carIdx) != 0) {
                    if (!started) { toStart(); started = true }
                    state = 1
                } else if (coins >= spec().price) {
                    coins -= spec().price; owned = owned or (1 shl carIdx)
                    store.s("coins", coins); store.s("owned", owned)
                }
            }
            id == 31 -> { tiltOn = !tiltOn; store.s("tilt", if (tiltOn) 1 else 0) }
            id == 32 -> { tiltInv = !tiltInv; store.s("tiltinv", if (tiltInv) 1 else 0) }
        }
    }

    fun adminAddCoins(amount: Int) {
        coins = (coins.toLong() + amount.coerceAtLeast(0)).coerceAtMost(2_000_000_000L).toInt()
        store.s("coins", coins); toast("ADMIN: +$amount COINS")
    }

    fun adminUnlockAll() {
        owned = (1 shl CARS.size) - 1
        store.s("owned", owned); toast("ADMIN: ALL CARS UNLOCKED")
    }

    fun adminMaxUpgrades() {
        for (i in CARS.indices) for (k in 0..2) store.s("u${i}_$k", 5)
        applySpec(); toast("ADMIN: UPGRADES MAXED")
    }

    fun adminToggle(key: String, enabled: Boolean) {
        when (key) {
            "nitro" -> { adminInfiniteNitro = enabled; store.s("admin_nitro", if (enabled) 1 else 0) }
            "god" -> { adminGodMode = enabled; store.s("admin_god", if (enabled) 1 else 0) }
            "drift" -> { adminFiveXDrift = enabled; store.s("admin_drift", if (enabled) 1 else 0) }
            "torque" -> { adminDoubleTorque = enabled; store.s("admin_torque", if (enabled) 1 else 0); applySpec() }
        }
    }

    fun adminSetPaint(index: Int) {
        paintIdx = index.coerceIn(PAINTS.indices)
        store.s("paint", paintIdx); carVersion++
    }

    fun adminResetSave() {
        val keys = listOf("coins", "car", "paint", "owned", "best", "tilt", "tiltinv", "admin_nitro", "admin_god", "admin_drift", "admin_torque")
        val editor = store.editor()
        keys.forEach { editor.remove(it) }
        for (i in CARS.indices) for (k in 0..2) editor.remove("u${i}_$k")
        editor.apply()
        coins = 5000; carIdx = 0; paintIdx = 0; owned = 1; best = 0
        tiltOn = false; tiltInv = false
        totalScore = 0; nitro = 1f; driftPts = 0f; driftT = 0f; mult = 1
        started = false; state = 0; toStart()
        adminInfiniteNitro = false; adminGodMode = false; adminFiveXDrift = false; adminDoubleTorque = false
        applySpec(); carVersion++; toast("SAVE RESET")
    }

    fun cycleCam() { camMode = (camMode + 1) % 3 }
    fun toGarage() { bank(); state = 0 }

    fun resetCar() {
        val i = world.nearest(car.x, car.z)
        car.place(world.tx[i], world.tz[i], world.startPsi(i))
        driftPts = 0f; driftT = 0f; camAng = car.psi
    }

    private fun bank() {
        if (driftPts > 20f) {
            val pts = driftPts.toInt()
            totalScore += pts
            coins += pts / 8
            store.s("coins", coins)
            if (pts > best) { best = pts; store.s("best", best) }
            toast("DRIFT +$pts   \$${pts / 8}")
        }
        driftPts = 0f; driftT = 0f; mult = 1
    }

    private fun spawnWheelFx(dt: Float, sn: Float, cs: Float) {
        val c = car
        val rear = c.rearSlip
        for (i in 0..3) {
            val xl = if (i % 2 == 0) 0.84f else -0.84f
            val zl = if (i < 2) -1.3f else 1.3f
            val wx = c.x + sn * zl + cs * xl
            val wz = c.z + cs * zl - sn * xl
            val slip = if (i < 2) rear else c.frontSlip * 0.6f
            if (slip > 0.35f && c.speed > 3f) {
                fx.skid(i, wx, wz, (0.15f + slip * 0.35f).coerceAtMost(0.5f))
                if (i < 2 && Random.nextFloat() < dt * 70f * slip) {
                    val sp = c.speed
                    fx.emit(wx, 0.3f, wz, (Random.nextFloat() - 0.5f) * 1.5f, 0.8f + Random.nextFloat(), (Random.nextFloat() - 0.5f) * 1.5f,
                        1.1f + Random.nextFloat() * 0.8f, 0.9f + sp * 0.02f, 0f)
                }
            } else fx.skidEnd(i)
        }
        if (nitroActive) {
            for (s in 0..1) {
                val xl = if (s == 0) 0.45f else -0.45f
                val zl = -2.25f
                val wx = c.x + sn * zl + cs * xl; val wz = c.z + cs * zl - sn * xl
                fx.emit(wx, 0.42f, wz, -sn * 8f, 0f, -cs * 8f, 0.16f, 0.5f, 1f)
            }
        }
    }

    private fun axisSteer(): Float {
        var s = (if (keyL) 1f else 0f) - (if (keyR) 1f else 0f)
        s += (if (touchL) 1f else 0f) - (if (touchR) 1f else 0f)
        s += padSteer
        if (tiltOn) s += tilt * (if (tiltInv) -1f else 1f)
        return s.coerceIn(-1f, 1f)
    }

    fun update(dt: Float) {
        time += dt
        if (toastT > 0f) toastT -= dt
        if (state == 1) drive(dt) else { if (steerSm != 0f) steerSm = 0f }
        fx.update(dt)
        updateCamera(dt)
    }

    private fun drive(dt: Float) {
        val c = car
        val target = axisSteer()
        val rate = if (target == 0f || target * steerSm < 0f) 14f else 7f / (1f + c.speed / 45f) + 2.5f
        steerSm += (target - steerSm) * min(1f, dt * rate)
        steerShown = steerSm
        val gasT = if (touchGas || keyGas) 1f else padGas
        thrSm += (gasT - thrSm) * min(1f, dt * 12f)
        val brk = if (touchBrk || keyBrk) 1f else padBrk
        braking = brk > 0.1f
        val hb = touchHb || keyHb
        val wantNitro = touchNit || keyNit
        if (adminInfiniteNitro) nitro = 1f
        nitroActive = wantNitro && (adminInfiniteNitro || nitro > 0.02f) && c.u > 3f
        if (adminInfiniteNitro) nitro = 1f
        else if (nitroActive) nitro = max(0f, nitro - dt * (0.30f - 0.03f * upg(2)))
        else nitro = min(1f, nitro + dt * (if (driftT > 0f) 0.10f else 0.025f))

        val n = ceil(dt / (1f / 240f)).toInt().coerceIn(1, 12)
        val h = dt / n
        for (i in 0 until n) c.step(h, steerSm, thrSm, brk, hb, nitroActive)

        val imp = if (adminGodMode) 0f else world.collide(c)
        if (imp > 3f) {
            shake = max(shake, (imp / 14f).coerceAtMost(1f))
            if (driftPts > 0f) { driftPts = 0f; driftT = 0f; mult = 1; toast("CRASH! combo lost") }
        }

        val sn = sin(c.psi); val cs = cos(c.psi)
        val b = abs(c.beta)
        driftAngleDeg = Math.toDegrees(b.toDouble()).toFloat()
        if (c.speed > 9f && b > 0.2f && c.u > 3f) {
            driftT += dt; graceT = 0f
            mult = 1 + (driftT / 2.5f).toInt().coerceAtMost(4)
            driftPts += c.speed * 3.6f * b * 4f * mult * dt * 0.35f * (if (adminFiveXDrift) 5f else 1f)
        } else if (driftPts > 0f) {
            graceT += dt
            if (graceT > 1.1f) bank()
        }
        spawnWheelFx(dt, sn, cs)
    }

    private fun updateCamera(dt: Float) {
        val c = car
        shake = max(0f, shake - dt * 2.2f)
        if (state == 0) {
            menuAng += dt * 0.35f
            val r = 7.4f
            camX = c.x + sin(menuAng) * r; camZ = c.z + cos(menuAng) * r; camY = 2.1f
            lookX = c.x; lookY = 0.75f; lookZ = c.z
            fov += (52f - fov) * min(1f, dt * 4f)
            return
        }
        val tgt = c.psi + (if (camMode == 2) 0.25f else 0.55f) * c.beta.coerceIn(-1f, 1f)
        var da = tgt - camAng
        while (da > PI) da -= (2 * PI).toFloat()
        while (da < -PI) da += (2 * PI).toFloat()
        camAng += da * min(1f, dt * 5f)
        val sp = c.speed
        val fx0 = sin(camAng); val fz0 = cos(camAng)
        when (camMode) {
            0 -> { val d = 6.8f + sp * 0.03f; camX = c.x - fx0 * d; camZ = c.z - fz0 * d; camY = 2.3f
                   lookX = c.x + fx0 * 4f; lookZ = c.z + fz0 * 4f; lookY = 1.0f }
            1 -> { val d = 11f + sp * 0.05f; camX = c.x - fx0 * d; camZ = c.z - fz0 * d; camY = 4.6f
                   lookX = c.x + fx0 * 6f; lookZ = c.z + fz0 * 6f; lookY = 0.8f }
            else -> { camX = c.x + sin(c.psi) * 0.5f; camZ = c.z + cos(c.psi) * 0.5f; camY = 1.18f
                   lookX = camX + fx0 * 30f; lookZ = camZ + fz0 * 30f; lookY = 1.0f }
        }
        if (shake > 0f) {
            camX += (Random.nextFloat() - 0.5f) * shake * 0.8f
            camY += (Random.nextFloat() - 0.5f) * shake * 0.5f
            camZ += (Random.nextFloat() - 0.5f) * shake * 0.8f
        }
        val tf = 60f + sp * 0.22f + (if (nitroActive) 12f else 0f)
        fov += (tf - fov) * min(1f, dt * 3f)
    }
}
