package com.neondrift.game

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.opengl.GLES30
import android.opengl.GLSurfaceView
import android.opengl.GLUtils
import android.opengl.Matrix
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.*

private const val MAIN_VS = """#version 300 es
layout(location=0) in vec3 aPos;
layout(location=1) in vec3 aNrm;
layout(location=2) in vec4 aCol;
layout(location=3) in vec2 aUV;
uniform mat4 uVP;
uniform mat4 uModel;
out vec3 vW; out vec3 vN; out vec4 vC; out vec2 vUV;
void main(){
  vec4 w = uModel*vec4(aPos,1.0);
  vW = w.xyz; vN = mat3(uModel)*aNrm; vC = aCol; vUV = aUV;
  gl_Position = uVP*w;
}"""

private const val MAIN_FS = """#version 300 es
precision highp float;
in vec3 vW; in vec3 vN; in vec4 vC; in vec2 vUV;
uniform vec3 uCam; uniform vec3 uSun; uniform vec3 uTint; uniform float uGloss;
uniform sampler2D uTex;
uniform vec3 uCarPos; uniform vec3 uCarDir; uniform float uHead;
uniform vec3 uFogC; uniform float uFogD; uniform vec3 uHor; uniform vec3 uZen;
out vec4 o;
void main(){
  vec3 N = normalize(vN); vec3 V = normalize(uCam - vW);
  if (dot(N,V) < 0.0) N = -N;
  vec3 base = vC.rgb * uTint;
  float em = vC.a;
  vec3 L = normalize(uSun);
  float dif = max(dot(N,L),0.0);
  vec3 col = base * (vec3(0.16,0.15,0.26) + dif*vec3(0.30,0.34,0.55));
  float fr = pow(1.0 - max(dot(N,V),0.0), 4.0);
  vec3 R = reflect(-V,N);
  vec3 sk = mix(uHor, uZen, clamp(R.y*1.4,0.0,1.0));
  col += sk * (fr*0.9 + 0.08) * uGloss;
  vec3 H = normalize(L+V);
  col += vec3(0.7,0.75,1.0) * pow(max(dot(N,H),0.0),80.0) * uGloss * 0.9;
  vec3 tp = vW - uCarPos; float dist = length(tp) + 0.001; vec3 td = tp/dist;
  float cone = smoothstep(0.86,0.97,dot(td,uCarDir));
  float att = 1.0/(1.0 + dist*dist*0.004);
  col += base * vec3(1.0,0.93,0.8) * cone * att * 2.4 * uHead * max(dot(N,-td),0.0);
  if (vUV.x >= 0.0) col += texture(uTex, vUV).rgb * 1.5;
  col = mix(col, base*2.0 + vec3(0.15), em);
  float d = length(uCam - vW);
  float f = clamp(1.0 - exp(-d*uFogD), 0.0, 1.0);
  col = mix(col, uFogC, f);
  col = (col*(2.51*col+0.03))/(col*(2.43*col+0.59)+0.14);
  col = pow(col, vec3(0.4545));
  o = vec4(col,1.0);
}"""

private const val SKY_VS = """#version 300 es
layout(location=0) in vec2 aP;
out vec2 vP;
void main(){ vP = aP; gl_Position = vec4(aP, 0.9999, 1.0); }"""

private const val SKY_FS = """#version 300 es
precision highp float;
in vec2 vP;
uniform vec3 uF; uniform vec3 uR; uniform vec3 uU; uniform vec2 uT;
uniform vec3 uHor; uniform vec3 uZen; uniform float uTime;
out vec4 o;
float hsh(vec2 p){ return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453); }
void main(){
  vec3 d = normalize(uF + vP.x*uT.x*uR + vP.y*uT.y*uU);
  float t = clamp(d.y,0.0,1.0);
  vec3 col = mix(uHor, uZen, pow(t,0.55));
  if (d.y < 0.0) col = uHor*0.6;
  vec2 sp = floor(vec2(atan(d.x,d.z)*160.0, d.y*160.0));
  float s = hsh(sp);
  float star = step(0.9962,s) * smoothstep(0.03,0.3,d.y);
  col += vec3(star) * (0.6 + 0.4*sin(uTime*2.0 + s*50.0));
  vec3 md = normalize(vec3(-0.45,0.42,0.78));
  float m = dot(d,md);
  col += vec3(0.9,0.93,1.0)*smoothstep(0.9984,0.9991,m) + vec3(0.25,0.3,0.55)*pow(max(m,0.0),60.0)*0.5;
  col = col/(1.0+col*0.4);
  col = pow(col, vec3(0.4545));
  o = vec4(col,1.0);
}"""

private const val SPR_VS = """#version 300 es
layout(location=0) in vec3 aC;
layout(location=1) in vec2 aK;
layout(location=2) in float aS;
layout(location=3) in vec4 aCol;
uniform mat4 uVP; uniform vec3 uRt; uniform vec3 uUp;
out vec2 vK; out vec4 vCol;
void main(){
  vec3 p = aC + (uRt*aK.x + uUp*aK.y)*aS;
  vK = aK; vCol = aCol;
  gl_Position = uVP*vec4(p,1.0);
}"""

private const val SPR_FS = """#version 300 es
precision mediump float;
in vec2 vK; in vec4 vCol;
uniform float uMode; uniform float uPow;
out vec4 o;
void main(){
  float r = length(vK);
  if (r > 1.0) discard;
  float a = pow(1.0 - r, uPow) * vCol.a;
  if (uMode > 0.5) o = vec4(vCol.rgb, a); else o = vec4(vCol.rgb*a, 1.0);
}"""

private const val DEC_VS = """#version 300 es
layout(location=0) in vec3 aP;
layout(location=1) in vec2 aUV;
layout(location=2) in vec4 aCol;
uniform mat4 uVP;
out vec2 vUV; out vec4 vCol;
void main(){ vUV = aUV; vCol = aCol; gl_Position = uVP*vec4(aP,1.0); }"""

private const val DEC_FS = """#version 300 es
precision mediump float;
in vec2 vUV; in vec4 vCol;
out vec4 o;
void main(){
  float a = vUV.x > 5.0 ? 1.0 : smoothstep(1.0,0.15,length(vUV));
  o = vec4(vCol.rgb, vCol.a*a);
}"""

private fun compile(type: Int, src: String): Int {
    val s = GLES30.glCreateShader(type)
    GLES30.glShaderSource(s, src)
    GLES30.glCompileShader(s)
    val st = IntArray(1)
    GLES30.glGetShaderiv(s, GLES30.GL_COMPILE_STATUS, st, 0)
    if (st[0] == 0) throw RuntimeException("Shader error: " + GLES30.glGetShaderInfoLog(s))
    return s
}

class Prog(vs: String, fs: String) {
    val id: Int = GLES30.glCreateProgram()
    private val locs = HashMap<String, Int>()
    init {
        GLES30.glAttachShader(id, compile(GLES30.GL_VERTEX_SHADER, vs))
        GLES30.glAttachShader(id, compile(GLES30.GL_FRAGMENT_SHADER, fs))
        GLES30.glLinkProgram(id)
        val st = IntArray(1)
        GLES30.glGetProgramiv(id, GLES30.GL_LINK_STATUS, st, 0)
        if (st[0] == 0) throw RuntimeException("Link error: " + GLES30.glGetProgramInfoLog(id))
    }
    fun u(n: String): Int = locs.getOrPut(n) { GLES30.glGetUniformLocation(id, n) }
}

class Gpu(val id: Int, val count: Int)

private fun fbuf(len: Int): FloatBuffer =
    ByteBuffer.allocateDirect(len * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()

private fun newBuf(): Int { val a = IntArray(1); GLES30.glGenBuffers(1, a, 0); return a[0] }

private fun uploadMesh(mb: MB): Gpu {
    val id = newBuf()
    val b = fbuf(mb.n); b.put(mb.d, 0, mb.n); b.position(0)
    GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, id)
    GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, mb.n * 4, b, GLES30.GL_STATIC_DRAW)
    return Gpu(id, mb.verts)
}

private fun enableAttribs(n: Int) {
    for (i in 0 until 4) if (i < n) GLES30.glEnableVertexAttribArray(i) else GLES30.glDisableVertexAttribArray(i)
}

class Renderer(private val g: Game) : GLSurfaceView.Renderer {
    private lateinit var main: Prog
    private lateinit var skyP: Prog
    private lateinit var sprP: Prog
    private lateinit var decP: Prog
    private lateinit var worldGpu: Gpu
    private var carGpu: Array<Gpu>? = null
    private var carVer = -1
    private var carStyle = -1
    private var tex = 0
    private val glows = ArrayList<FloatArray>()
    private var poolGpu: Gpu? = null
    private var skyBuf = 0
    private var sprBuf = 0
    private var decBuf = 0
    private var skidBuf = 0
    private val sprA = FloatArray(11 * 6 * 700)
    private val sprB = FloatArray(11 * 6 * 500)
    private val sprFB = fbuf(11 * 6 * 700)
    private val decA = FloatArray(9 * 6 * 4)
    private val decFB = fbuf(9 * 6 * 4)
    private val skFB = fbuf(1500 * 54)
    private val proj = FloatArray(16); private val view = FloatArray(16); private val vp = FloatArray(16)
    private val mBody = FloatArray(16); private val mYaw = FloatArray(16); private val mTmp = FloatArray(16)
    private var aspect = 1.78f
    private var last = 0L

    private val hor = floatArrayOf(0.20f, 0.07f, 0.30f)
    private val zen = floatArrayOf(0.012f, 0.012f, 0.06f)

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        main = Prog(MAIN_VS, MAIN_FS); skyP = Prog(SKY_VS, SKY_FS); sprP = Prog(SPR_VS, SPR_FS); decP = Prog(DEC_VS, DEC_FS)
        val pools = ArrayList<Float>()
        glows.clear()
        worldGpu = uploadMesh(buildWorld(g.world, glows, pools))
        // light pools (static decals)
        val np = pools.size / 3
        val pa = FloatArray(np * 54)
        for (i in 0 until np) {
            val cx = pools[i * 3]; val cz = pools[i * 3 + 1]; val r = pools[i * 3 + 2]
            val o = i * 54
            val cs = arrayOf(floatArrayOf(-1f, -1f), floatArrayOf(1f, -1f), floatArrayOf(1f, 1f), floatArrayOf(-1f, -1f), floatArrayOf(1f, 1f), floatArrayOf(-1f, 1f))
            for (k in 0 until 6) {
                val q = o + k * 9
                pa[q] = cx + cs[k][0] * r; pa[q + 1] = 0.1f; pa[q + 2] = cz + cs[k][1] * r
                pa[q + 3] = cs[k][0]; pa[q + 4] = cs[k][1]
                pa[q + 5] = 1f; pa[q + 6] = 0.75f; pa[q + 7] = 0.35f; pa[q + 8] = 0.20f
            }
        }
        val pid = newBuf()
        val pb = fbuf(pa.size); pb.put(pa); pb.position(0)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, pid)
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, pa.size * 4, pb, GLES30.GL_STATIC_DRAW)
        poolGpu = Gpu(pid, np * 6)

        skyBuf = newBuf(); sprBuf = newBuf(); decBuf = newBuf(); skidBuf = newBuf()
        val q = floatArrayOf(-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f)
        val qb = fbuf(8); qb.put(q); qb.position(0)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, skyBuf)
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, 32, qb, GLES30.GL_STATIC_DRAW)

        makeTexture()
        carVer = -1; carStyle = -1; carGpu = null
        GLES30.glEnable(GLES30.GL_DEPTH_TEST)
        last = 0L
    }

    private fun makeTexture() {
        val bmp = Bitmap.createBitmap(256, 256, Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp); cv.drawColor(Color.BLACK)
        val p = Paint(); val rnd = java.util.Random(3)
        for (cy in 0 until 8) for (cx in 0 until 8) {
            val x = cx * 32f; val y = cy * 32f
            p.color = Color.rgb(8, 11, 24); cv.drawRect(x + 7, y + 8, x + 25, y + 26, p)
            if (rnd.nextFloat() < 0.42f) {
                val k = rnd.nextFloat()
                p.color = when {
                    k < 0.55f -> Color.rgb(255, 205, 130)
                    k < 0.80f -> Color.rgb(170, 210, 255)
                    k < 0.90f -> Color.rgb(255, 80, 200)
                    else -> Color.rgb(0, 255, 230)
                }
                cv.drawRect(x + 7, y + 8, x + 25, y + 26, p)
            }
        }
        val id = IntArray(1); GLES30.glGenTextures(1, id, 0); tex = id[0]
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, tex)
        GLUtils.texImage2D(GLES30.GL_TEXTURE_2D, 0, bmp, 0)
        GLES30.glGenerateMipmap(GLES30.GL_TEXTURE_2D)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR_MIPMAP_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_REPEAT)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_REPEAT)
        bmp.recycle()
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        GLES30.glViewport(0, 0, width, height)
        aspect = width.toFloat() / max(1, height)
    }

    private fun rebuildCar() {
        val style = g.spec().style
        if (style != carStyle || carGpu == null) {
            val m = buildCar(style)
            carGpu = arrayOf(uploadMesh(m.paint), uploadMesh(m.trim), uploadMesh(m.head), uploadMesh(m.tail), uploadMesh(m.wheel))
            carStyle = style
        }
        carVer = g.carVersion
    }

    private fun drawMesh(m: Gpu, model: FloatArray, tr: Float, tg: Float, tb: Float, gloss: Float) {
        GLES30.glUniformMatrix4fv(main.u("uModel"), 1, false, model, 0)
        GLES30.glUniform3f(main.u("uTint"), tr, tg, tb)
        GLES30.glUniform1f(main.u("uGloss"), gloss)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, m.id)
        GLES30.glVertexAttribPointer(0, 3, GLES30.GL_FLOAT, false, 48, 0)
        GLES30.glVertexAttribPointer(1, 3, GLES30.GL_FLOAT, false, 48, 12)
        GLES30.glVertexAttribPointer(2, 4, GLES30.GL_FLOAT, false, 48, 24)
        GLES30.glVertexAttribPointer(3, 2, GLES30.GL_FLOAT, false, 48, 40)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, m.count)
    }

    private fun sprite(a: FloatArray, idx: Int, x: Float, y: Float, z: Float, s: Float, r: Float, gg: Float, b: Float, al: Float): Int {
        var i = idx
        if (i + 66 > a.size) return i
        val ks = SPR_K
        for (k in 0 until 6) {
            a[i++] = x; a[i++] = y; a[i++] = z
            a[i++] = ks[k * 2]; a[i++] = ks[k * 2 + 1]
            a[i++] = s
            a[i++] = r; a[i++] = gg; a[i++] = b; a[i++] = al
            a[i++] = 0f
        }
        return i
    }

    override fun onDrawFrame(gl: GL10?) {
        val now = System.nanoTime()
        var dt = if (last == 0L) 0.016f else (now - last) / 1e9f
        last = now
        dt = dt.coerceIn(0.001f, 0.05f)
        g.update(dt)
        if (carVer != g.carVersion || carGpu == null) rebuildCar()
        val car = g.car

        GLES30.glClearColor(hor[0], hor[1], hor[2], 1f)
        GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT or GLES30.GL_DEPTH_BUFFER_BIT)

        Matrix.perspectiveM(proj, 0, g.fov, aspect, 0.5f, 1400f)
        Matrix.setLookAtM(view, 0, g.camX, g.camY, g.camZ, g.lookX, g.lookY, g.lookZ, 0f, 1f, 0f)
        Matrix.multiplyMM(vp, 0, proj, 0, view, 0)

        var fX = g.lookX - g.camX; var fY = g.lookY - g.camY; var fZ = g.lookZ - g.camZ
        val fl = sqrt(fX * fX + fY * fY + fZ * fZ); fX /= fl; fY /= fl; fZ /= fl
        var rX = fY * 0f - fZ * 1f; var rY = fZ * 0f - fX * 0f; var rZ = fX * 1f - fY * 0f
        val rl = sqrt(rX * rX + rY * rY + rZ * rZ); rX /= rl; rY /= rl; rZ /= rl
        val uX = rY * fZ - rZ * fY; val uY = rZ * fX - rX * fZ; val uZ = rX * fY - rY * fX

        // ---- sky ----
        GLES30.glDisable(GLES30.GL_DEPTH_TEST)
        GLES30.glUseProgram(skyP.id)
        val ty = tan(Math.toRadians(g.fov / 2.0)).toFloat()
        GLES30.glUniform3f(skyP.u("uF"), fX, fY, fZ); GLES30.glUniform3f(skyP.u("uR"), rX, rY, rZ); GLES30.glUniform3f(skyP.u("uU"), uX, uY, uZ)
        GLES30.glUniform2f(skyP.u("uT"), ty * aspect, ty)
        GLES30.glUniform3f(skyP.u("uHor"), hor[0], hor[1], hor[2]); GLES30.glUniform3f(skyP.u("uZen"), zen[0], zen[1], zen[2])
        GLES30.glUniform1f(skyP.u("uTime"), g.time)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, skyBuf)
        enableAttribs(1)
        GLES30.glVertexAttribPointer(0, 2, GLES30.GL_FLOAT, false, 8, 0)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLE_STRIP, 0, 4)
        GLES30.glEnable(GLES30.GL_DEPTH_TEST)

        // ---- opaque ----
        GLES30.glUseProgram(main.id)
        GLES30.glUniformMatrix4fv(main.u("uVP"), 1, false, vp, 0)
        GLES30.glUniform3f(main.u("uCam"), g.camX, g.camY, g.camZ)
        GLES30.glUniform3f(main.u("uSun"), -0.45f, 0.42f, 0.78f)
        GLES30.glUniform3f(main.u("uHor"), hor[0], hor[1], hor[2]); GLES30.glUniform3f(main.u("uZen"), zen[0], zen[1], zen[2])
        GLES30.glUniform3f(main.u("uFogC"), hor[0] * 0.9f, hor[1] * 0.9f, hor[2] * 0.9f)
        GLES30.glUniform1f(main.u("uFogD"), 0.0042f)
        val sn = sin(car.psi); val cs = cos(car.psi)
        GLES30.glUniform3f(main.u("uCarPos"), car.x, 0.6f, car.z)
        val dl = sqrt(1f + 0.0144f)
        GLES30.glUniform3f(main.u("uCarDir"), sn / dl, -0.12f / dl, cs / dl)
        GLES30.glUniform1f(main.u("uHead"), 1f)
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0); GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, tex)
        GLES30.glUniform1i(main.u("uTex"), 0)
        enableAttribs(4)
        Matrix.setIdentityM(mTmp, 0)
        drawMesh(worldGpu, mTmp, 1f, 1f, 1f, 0.35f)

        val cg = carGpu!!
        val pc = PAINTS[g.paintIdx]
        Matrix.setIdentityM(mYaw, 0)
        Matrix.translateM(mYaw, 0, car.x, 0f, car.z)
        Matrix.rotateM(mYaw, 0, Math.toDegrees(car.psi.toDouble()).toFloat(), 0f, 1f, 0f)
        System.arraycopy(mYaw, 0, mBody, 0, 16)
        val pitch = (-car.ax * 0.5f).coerceIn(-4f, 4f)
        val roll = (car.ay * 0.35f).coerceIn(-5f, 5f)
        Matrix.translateM(mBody, 0, 0f, 0.45f, 0f)
        Matrix.rotateM(mBody, 0, pitch, 1f, 0f, 0f)
        Matrix.rotateM(mBody, 0, roll, 0f, 0f, 1f)
        Matrix.translateM(mBody, 0, 0f, -0.45f, 0f)
        drawMesh(cg[0], mBody, pc[0], pc[1], pc[2], 1.0f)
        drawMesh(cg[1], mBody, 1f, 1f, 1f, 0.8f)
        drawMesh(cg[2], mBody, 1f, 1f, 1f, 0f)
        val tl = if (g.braking) 1.9f else 0.7f
        drawMesh(cg[3], mBody, tl, tl, tl, 0f)
        val steerDeg = Math.toDegrees(car.steerAngle.toDouble()).toFloat()
        val spinDeg = Math.toDegrees(car.wheelSpin.toDouble()).toFloat()
        for (i in 0..3) {
            val xl = if (i % 2 == 0) 0.84f else -0.84f
            val zl = if (i < 2) -1.3f else 1.3f
            System.arraycopy(mYaw, 0, mTmp, 0, 16)
            Matrix.translateM(mTmp, 0, xl, 0.34f, zl)
            if (i >= 2) Matrix.rotateM(mTmp, 0, steerDeg, 0f, 1f, 0f)
            Matrix.rotateM(mTmp, 0, spinDeg, 1f, 0f, 0f)
            drawMesh(cg[4], mTmp, 1f, 1f, 1f, 0.3f)
        }

        // ---- decals ----
        GLES30.glEnable(GLES30.GL_BLEND)
        GLES30.glBlendFunc(GLES30.GL_SRC_ALPHA, GLES30.GL_ONE_MINUS_SRC_ALPHA)
        GLES30.glDepthMask(false)
        GLES30.glUseProgram(decP.id)
        GLES30.glUniformMatrix4fv(decP.u("uVP"), 1, false, vp, 0)
        enableAttribs(3)
        poolGpu?.let { drawDecal(it.id, it.count) }
        if (g.fx.skCount > 0) {
            val fx = g.fx
            skFB.clear()
            if (fx.skCount == fx.skMax) {
                skFB.put(fx.sk, fx.skHead * 54, (fx.skMax - fx.skHead) * 54)
                skFB.put(fx.sk, 0, fx.skHead * 54)
            } else skFB.put(fx.sk, 0, fx.skCount * 54)
            skFB.position(0)
            GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, skidBuf)
            GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, fx.skCount * 54 * 4, skFB, GLES30.GL_STREAM_DRAW)
            drawDecalBound(fx.skCount * 6)
        }
        // underglow + shadow
        var di = 0
        di = decQuad(decA, di, car.x, car.z, sn, cs, 3.1f, 1.9f, 0.10f, 1f, 0.15f, 0.9f, 0.35f)
        di = decQuad(decA, di, car.x, car.z, sn, cs, 2.6f, 1.4f, 0.11f, 0f, 0f, 0f, 0.55f)
        decFB.clear(); decFB.put(decA, 0, di); decFB.position(0)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, decBuf)
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, di * 4, decFB, GLES30.GL_STREAM_DRAW)
        drawDecalBound(di / 9)

        // ---- sprites ----
        GLES30.glUseProgram(sprP.id)
        GLES30.glUniformMatrix4fv(sprP.u("uVP"), 1, false, vp, 0)
        GLES30.glUniform3f(sprP.u("uRt"), rX, rY, rZ); GLES30.glUniform3f(sprP.u("uUp"), uX, uY, uZ)
        var ia = 0; var ib = 0
        val cx = g.camX; val cz = g.camZ
        for (gw in glows) {
            val dx = gw[0] - cx; val dz = gw[2] - cz
            if (dx * dx + dz * dz > 300f * 300f) continue
            if (dx * fX + dz * fZ < -20f) continue
            ia = sprite(sprA, ia, gw[0], gw[1], gw[2], gw[3], gw[4], gw[5], gw[6], 0.55f)
        }
        // headlight / taillight glow
        val hx = sn * 2.0f; val hz = cs * 2.0f
        ia = sprite(sprA, ia, car.x + hx + cs * 0.62f, 0.6f, car.z + hz - sn * 0.62f, 1.1f, 0.9f, 0.95f, 1f, 0.9f)
        ia = sprite(sprA, ia, car.x + hx - cs * 0.62f, 0.6f, car.z + hz + sn * 0.62f, 1.1f, 0.9f, 0.95f, 1f, 0.9f)
        val tb = if (g.braking) 1.0f else 0.5f
        ia = sprite(sprA, ia, car.x - sn * 2.15f, 0.82f, car.z - cs * 2.15f, 1.5f, 1f, 0.05f, 0.05f, tb)
        val p = g.fx.p
        for (i in 0 until g.fx.cnt) {
            val o = i * 10
            val age = p[o + 6] / p[o + 7]
            if (p[o + 9] > 0.5f) {
                ia = sprite(sprA, ia, p[o], p[o + 1], p[o + 2], p[o + 8] * (1f - age * 0.5f), 1f, 0.55f + 0.3f * age, 0.15f, 0.9f * (1f - age))
            } else {
                ib = sprite(sprB, ib, p[o], p[o + 1], p[o + 2], p[o + 8] * (0.6f + age * 2.2f), 0.75f, 0.75f, 0.82f, 0.35f * (1f - age))
            }
        }
        enableAttribs(4)
        if (ia > 0) drawSprites(sprA, ia, 0f, 2.2f)
        if (ib > 0) { GLES30.glBlendFunc(GLES30.GL_SRC_ALPHA, GLES30.GL_ONE_MINUS_SRC_ALPHA); drawSprites(sprB, ib, 1f, 0.8f) }

        GLES30.glDepthMask(true)
        GLES30.glDisable(GLES30.GL_BLEND)
    }

    private fun drawSprites(a: FloatArray, len: Int, mode: Float, pw: Float) {
        if (mode < 0.5f) GLES30.glBlendFunc(GLES30.GL_ONE, GLES30.GL_ONE)
        sprFB.clear(); sprFB.put(a, 0, len); sprFB.position(0)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, sprBuf)
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, len * 4, sprFB, GLES30.GL_STREAM_DRAW)
        GLES30.glUniform1f(sprP.u("uMode"), mode); GLES30.glUniform1f(sprP.u("uPow"), pw)
        GLES30.glVertexAttribPointer(0, 3, GLES30.GL_FLOAT, false, 44, 0)
        GLES30.glVertexAttribPointer(1, 2, GLES30.GL_FLOAT, false, 44, 12)
        GLES30.glVertexAttribPointer(2, 1, GLES30.GL_FLOAT, false, 44, 20)
        GLES30.glVertexAttribPointer(3, 4, GLES30.GL_FLOAT, false, 44, 24)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, len / 11)
    }

    private fun drawDecal(id: Int, count: Int) {
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, id)
        drawDecalBound(count)
    }

    private fun drawDecalBound(count: Int) {
        GLES30.glVertexAttribPointer(0, 3, GLES30.GL_FLOAT, false, 36, 0)
        GLES30.glVertexAttribPointer(1, 2, GLES30.GL_FLOAT, false, 36, 12)
        GLES30.glVertexAttribPointer(2, 4, GLES30.GL_FLOAT, false, 36, 20)
        GLES30.glDrawArrays(GLES30.GL_TRIANGLES, 0, count)
    }

    private fun decQuad(a: FloatArray, idx: Int, cx: Float, cz: Float, sn: Float, cs: Float, hl: Float, hw: Float, y: Float,
                        r: Float, gg: Float, b: Float, al: Float): Int {
        var i = idx
        val fxv = sn * hl; val fzv = cs * hl; val lx = cs * hw; val lz = -sn * hw
        val px = floatArrayOf(cx - fxv - lx, cx + fxv - lx, cx + fxv + lx, cx - fxv - lx, cx + fxv + lx, cx - fxv + lx)
        val pz = floatArrayOf(cz - fzv - lz, cz + fzv - lz, cz + fzv + lz, cz - fzv - lz, cz + fzv + lz, cz - fzv + lz)
        val uu = floatArrayOf(-1f, -1f, 1f, -1f, 1f, 1f, -1f, -1f, 1f, 1f, -1f, 1f)
        for (k in 0 until 6) {
            a[i++] = px[k]; a[i++] = y; a[i++] = pz[k]; a[i++] = uu[k * 2]; a[i++] = uu[k * 2 + 1]
            a[i++] = r; a[i++] = gg; a[i++] = b; a[i++] = al
        }
        return i
    }

    companion object {
        private val SPR_K = floatArrayOf(-1f, -1f, 1f, -1f, 1f, 1f, -1f, -1f, 1f, 1f, -1f, 1f)
    }
}
