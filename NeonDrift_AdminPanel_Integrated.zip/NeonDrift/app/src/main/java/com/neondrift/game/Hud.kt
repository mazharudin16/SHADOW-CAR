package com.neondrift.game

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import kotlin.math.*

class HudView(ctx: Context, private val g: Game) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD) }
    private var W = 1f; private var H = 1f
    private val cyan = Color.rgb(0, 229, 255)
    private val mag = Color.rgb(255, 43, 214)
    private val panel = Color.argb(170, 8, 6, 28)

    private val zL = RectF(); private val zR = RectF(); private val zGas = RectF(); private val zBrk = RectF()
    private val zHb = RectF(); private val zNit = RectF(); private val zMenu = RectF(); private val zCam = RectF(); private val zReset = RectF()
    private class Btn(val r: RectF, val id: Int)
    private val btns = ArrayList<Btn>()
    private val mapPath = Path()
    private val mapM = Matrix()
    private var mapSize = 100f

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        W = w.toFloat(); H = h.toFloat()
        fun z(r: RectF, l: Float, t: Float, rr: Float, b: Float) { r.set(l * W, t * H, rr * W, b * H) }
        z(zL, 0.03f, 0.60f, 0.17f, 0.97f); z(zR, 0.19f, 0.60f, 0.33f, 0.97f)
        z(zGas, 0.80f, 0.56f, 0.97f, 0.97f); z(zBrk, 0.66f, 0.70f, 0.78f, 0.97f)
        z(zHb, 0.66f, 0.44f, 0.78f, 0.68f); z(zNit, 0.80f, 0.32f, 0.97f, 0.54f)
        z(zMenu, 0.91f, 0.03f, 0.98f, 0.14f); z(zCam, 0.82f, 0.03f, 0.89f, 0.14f); z(zReset, 0.73f, 0.03f, 0.80f, 0.14f)
        mapSize = H * 0.26f
        val w0 = g.world
        var mnx = 1e9f; var mxx = -1e9f; var mnz = 1e9f; var mxz = -1e9f
        for (i in 0 until w0.n) { mnx = min(mnx, w0.tx[i]); mxx = max(mxx, w0.tx[i]); mnz = min(mnz, w0.tz[i]); mxz = max(mxz, w0.tz[i]) }
        val sc = mapSize / max(mxx - mnx, mxz - mnz)
        mapPath.reset()
        for (i in 0 until w0.n) {
            val x = (w0.tx[i] - mnx) * sc; val y = (mxz - w0.tz[i]) * sc
            if (i == 0) mapPath.moveTo(x, y) else mapPath.lineTo(x, y)
        }
        mapPath.close()
        mapM.setScale(sc, sc); mapMinX = mnx; mapMaxZ = mxz; mapScale = sc
    }
    private var mapMinX = 0f; private var mapMaxZ = 0f; private var mapScale = 1f

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val act = e.actionMasked
        if (g.state == 0) {
            if (act == MotionEvent.ACTION_DOWN || act == MotionEvent.ACTION_POINTER_DOWN) {
                val i = e.actionIndex
                for (b in btns) if (b.r.contains(e.getX(i), e.getY(i))) { g.menuAction(b.id); break }
            }
            return true
        }
        var l = false; var r = false; var gas = false; var brk = false; var hb = false; var nit = false
        val up = act == MotionEvent.ACTION_UP || act == MotionEvent.ACTION_CANCEL
        if (!up) for (i in 0 until e.pointerCount) {
            if (act == MotionEvent.ACTION_POINTER_UP && i == e.actionIndex) continue
            val x = e.getX(i); val y = e.getY(i)
            if (!g.tiltOn) { if (zL.contains(x, y)) l = true; if (zR.contains(x, y)) r = true }
            if (zGas.contains(x, y)) gas = true
            if (zBrk.contains(x, y)) brk = true
            if (zHb.contains(x, y)) hb = true
            if (zNit.contains(x, y)) nit = true
        }
        if (act == MotionEvent.ACTION_DOWN || act == MotionEvent.ACTION_POINTER_DOWN) {
            val i = e.actionIndex; val x = e.getX(i); val y = e.getY(i)
            if (zMenu.contains(x, y)) g.toGarage()
            if (zCam.contains(x, y)) g.cycleCam()
            if (zReset.contains(x, y)) g.resetCar()
        }
        g.touchL = l; g.touchR = r; g.touchGas = gas; g.touchBrk = brk; g.touchHb = hb; g.touchNit = nit
        return true
    }

    override fun onDraw(c: Canvas) {
        btns.clear()
        if (g.state == 0) drawGarage(c) else drawPlay(c)
        postInvalidateOnAnimation()
    }

    private fun text(c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int, align: Paint.Align = Paint.Align.LEFT) {
        tp.textSize = size; tp.color = color; tp.textAlign = align
        c.drawText(s, x, y, tp)
    }

    private fun rbox(c: Canvas, r: RectF, fill: Int, stroke: Int = 0, sw: Float = 3f) {
        p.style = Paint.Style.FILL; p.color = fill
        c.drawRoundRect(r, H * 0.02f, H * 0.02f, p)
        if (stroke != 0) { p.style = Paint.Style.STROKE; p.strokeWidth = sw; p.color = stroke; c.drawRoundRect(r, H * 0.02f, H * 0.02f, p) }
    }

    private fun ctl(c: Canvas, r: RectF, label: String, on: Boolean, col: Int) {
        rbox(c, r, if (on) Color.argb(200, Color.red(col), Color.green(col), Color.blue(col)) else Color.argb(90, 10, 8, 30), col, 3f)
        text(c, label, r.centerX(), r.centerY() + H * 0.02f, H * 0.045f, if (on) Color.BLACK else Color.WHITE, Paint.Align.CENTER)
    }

    private fun drawPlay(c: Canvas) {
        val car = g.car
        // minimap
        val mp = RectF(W * 0.02f, H * 0.03f, W * 0.02f + mapSize, H * 0.03f + mapSize)
        rbox(c, mp, panel, cyan, 2f)
        c.save(); c.translate(mp.left, mp.top)
        p.style = Paint.Style.STROKE; p.strokeWidth = 4f; p.color = Color.argb(200, 255, 255, 255)
        c.drawPath(mapPath, p)
        p.style = Paint.Style.FILL; p.color = mag
        c.drawCircle((car.x - mapMinX) * mapScale, (mapMaxZ - car.z) * mapScale, H * 0.016f, p)
        c.restore()

        // drift panel
        val cx = W / 2f
        if (g.driftPts > 0f) {
            val r = RectF(cx - W * 0.17f, H * 0.02f, cx + W * 0.17f, H * 0.19f)
            rbox(c, r, panel, mag)
            text(c, "DRIFT  ${g.driftAngleDeg.toInt()}°", cx, H * 0.065f, H * 0.04f, cyan, Paint.Align.CENTER)
            text(c, "${g.driftPts.toInt()}", cx - W * 0.03f, H * 0.14f, H * 0.075f, Color.WHITE, Paint.Align.CENTER)
            text(c, "x${g.mult}", cx + W * 0.10f, H * 0.14f, H * 0.065f, mag, Paint.Align.CENTER)
        } else {
            text(c, "SCORE ${g.totalScore}    $ ${g.coins}", cx, H * 0.06f, H * 0.04f, Color.WHITE, Paint.Align.CENTER)
        }
        if (g.toastT > 0f) text(c, g.toast, cx, H * 0.27f, H * 0.055f, Color.argb(min(255, (g.toastT * 400).toInt()), 255, 230, 80), Paint.Align.CENTER)

        // top buttons
        ctl(c, zMenu, "II", false, cyan); ctl(c, zCam, "CAM", false, cyan); ctl(c, zReset, "RST", false, cyan)

        // speedometer
        val sx = W * 0.50f; val sy = H * 0.84f; val rad = H * 0.15f
        val oval = RectF(sx - rad, sy - rad, sx + rad, sy + rad)
        p.style = Paint.Style.STROKE; p.strokeWidth = H * 0.025f; p.color = Color.argb(120, 255, 255, 255)
        c.drawArc(oval, 150f, 240f, false, p)
        val rp = (car.rpm / 8000f).coerceIn(0f, 1f)
        p.color = if (rp > 0.88f) Color.rgb(255, 60, 60) else cyan
        c.drawArc(oval, 150f, 240f * rp, false, p)
        text(c, "${(car.u.coerceAtLeast(0f) * 3.6f).toInt()}", sx, sy + H * 0.02f, H * 0.095f, Color.WHITE, Paint.Align.CENTER)
        text(c, "KM/H", sx, sy + H * 0.075f, H * 0.032f, cyan, Paint.Align.CENTER)
        text(c, if (car.u < -0.5f) "R" else "${car.gear + 1}", sx, sy - H * 0.075f, H * 0.055f, mag, Paint.Align.CENTER)

        // nitro bar
        val nb = RectF(sx - W * 0.11f, H * 0.965f, sx + W * 0.11f, H * 0.985f)
        rbox(c, nb, Color.argb(120, 0, 0, 0), cyan, 2f)
        p.style = Paint.Style.FILL; p.color = if (g.nitroActive) Color.rgb(255, 160, 40) else mag
        c.drawRoundRect(RectF(nb.left, nb.top, nb.left + nb.width() * g.nitro, nb.bottom), 6f, 6f, p)

        // controls
        if (!g.tiltOn) { ctl(c, zL, "◀", g.touchL, cyan); ctl(c, zR, "▶", g.touchR, cyan) }
        else text(c, "TILT STEERING", W * 0.18f, H * 0.85f, H * 0.04f, cyan, Paint.Align.CENTER)
        ctl(c, zGas, "GAS", g.touchGas, Color.rgb(60, 255, 120))
        ctl(c, zBrk, "BRAKE", g.touchBrk, Color.rgb(255, 70, 70))
        ctl(c, zHb, "DRIFT", g.touchHb, mag)
        ctl(c, zNit, "NITRO", g.touchNit || g.nitroActive, Color.rgb(255, 160, 40))
    }

    private fun btn(c: Canvas, r: RectF, id: Int, label: String, sel: Boolean = false, col: Int = cyan, enabled: Boolean = true) {
        rbox(c, r, if (sel) Color.argb(220, Color.red(col), Color.green(col), Color.blue(col)) else panel, if (enabled) col else Color.GRAY, 3f)
        text(c, label, r.centerX(), r.centerY() + H * 0.016f, H * 0.04f, if (sel) Color.BLACK else if (enabled) Color.WHITE else Color.GRAY, Paint.Align.CENTER)
        btns.add(Btn(r, id))
    }

    private fun drawGarage(c: Canvas) {
        val s = g.spec()
        val own = g.owned and (1 shl g.carIdx) != 0
        text(c, "NEON DRIFT", W * 0.03f, H * 0.095f, H * 0.075f, mag)
        text(c, "GARAGE", W * 0.03f, H * 0.15f, H * 0.04f, cyan)
        text(c, "$ ${g.coins}", W * 0.97f, H * 0.08f, H * 0.055f, Color.rgb(255, 230, 80), Paint.Align.RIGHT)
        text(c, "BEST ${g.best}", W * 0.97f, H * 0.135f, H * 0.035f, Color.WHITE, Paint.Align.RIGHT)

        // car select
        btn(c, RectF(W * 0.03f, H * 0.40f, W * 0.09f, H * 0.52f), 1, "◀")
        btn(c, RectF(W * 0.38f, H * 0.40f, W * 0.44f, H * 0.52f), 2, "▶")
        val info = RectF(W * 0.03f, H * 0.18f, W * 0.44f, H * 0.37f)
        rbox(c, info, panel, mag)
        text(c, s.name, info.left + W * 0.015f, info.top + H * 0.065f, H * 0.06f, Color.WHITE)
        text(c, s.desc + (if (own) "" else "   [LOCKED]"), info.left + W * 0.015f, info.top + H * 0.12f, H * 0.035f, cyan)
        val power = (s.torque / 600f).coerceIn(0f, 1f); val grip = ((s.muR - 0.8f) / 0.5f).coerceIn(0f, 1f); val light = (1f - (s.mass - 1000f) / 700f).coerceIn(0f, 1f)
        bar(c, info.left + W * 0.015f, info.bottom - H * 0.05f, "PWR", power)
        bar(c, info.left + W * 0.15f, info.bottom - H * 0.05f, "GRIP", grip)
        bar(c, info.left + W * 0.28f, info.bottom - H * 0.05f, "AGIL", light)

        // paint
        text(c, "PAINT", W * 0.11f, H * 0.455f, H * 0.032f, Color.WHITE)
        for (i in PAINTS.indices) {
            val pc = PAINTS[i]
            val r = RectF(W * (0.03f + i * 0.0445f), H * 0.56f, W * (0.03f + i * 0.0445f + 0.038f), H * 0.56f + W * 0.038f)
            p.style = Paint.Style.FILL; p.color = Color.rgb((pc[0] * 255).toInt(), (pc[1] * 255).toInt(), (pc[2] * 255).toInt())
            c.drawRoundRect(r, 8f, 8f, p)
            if (i == g.paintIdx) { p.style = Paint.Style.STROKE; p.strokeWidth = 5f; p.color = Color.WHITE; c.drawRoundRect(r, 8f, 8f, p) }
            btns.add(Btn(r, 10 + i))
        }

        // upgrades
        text(c, "UPGRADES", W * 0.55f, H * 0.22f, H * 0.04f, cyan)
        for (k in 0..2) {
            val lv = g.upg(k)
            val y = H * (0.25f + k * 0.13f)
            val r = RectF(W * 0.55f, y, W * 0.97f, y + H * 0.11f)
            rbox(c, r, panel, cyan, 2f)
            text(c, UPG_NAMES[k], r.left + W * 0.015f, r.centerY() + H * 0.015f, H * 0.04f, Color.WHITE)
            for (i in 0 until 5) {
                p.style = Paint.Style.FILL; p.color = if (i < lv) mag else Color.argb(90, 255, 255, 255)
                c.drawRoundRect(RectF(r.left + W * (0.13f + i * 0.03f), r.centerY() - H * 0.02f, r.left + W * (0.13f + i * 0.03f + 0.022f), r.centerY() + H * 0.02f), 4f, 4f, p)
            }
            val cost = (lv + 1) * UPG_COST[k]
            val br = RectF(r.right - W * 0.14f, r.top + H * 0.015f, r.right - W * 0.01f, r.bottom - H * 0.015f)
            if (lv >= 5) btn(c, br, -1, "MAX", false, Color.GRAY, false)
            else btn(c, br, 20 + k, "$$cost", false, Color.rgb(255, 230, 80), g.coins >= cost)
        }
        // controls options
        btn(c, RectF(W * 0.55f, H * 0.65f, W * 0.75f, H * 0.74f), 31, if (g.tiltOn) "TILT: ON" else "TILT: OFF", g.tiltOn)
        btn(c, RectF(W * 0.77f, H * 0.65f, W * 0.97f, H * 0.74f), 32, if (g.tiltInv) "INVERT: ON" else "INVERT: OFF", g.tiltInv)
        text(c, "Keys: WASD/arrows  SPACE=drift  SHIFT=nitro  C=cam  R=reset", W * 0.03f, H * 0.93f, H * 0.03f, Color.argb(200, 255, 255, 255))
        val label = if (own) (if (g.started) "RESUME" else "DRIVE") else "BUY  $${s.price}"
        btn(c, RectF(W * 0.55f, H * 0.78f, W * 0.97f, H * 0.93f), 30, label, true, if (own || g.coins >= s.price) mag else Color.GRAY, own || g.coins >= s.price)
    }

    private fun bar(c: Canvas, x: Float, y: Float, label: String, v: Float) {
        text(c, label, x, y, H * 0.026f, Color.WHITE)
        p.style = Paint.Style.FILL; p.color = Color.argb(90, 255, 255, 255)
        c.drawRoundRect(RectF(x, y + H * 0.012f, x + W * 0.12f, y + H * 0.03f), 6f, 6f, p)
        p.color = cyan
        c.drawRoundRect(RectF(x, y + H * 0.012f, x + W * 0.12f * v, y + H * 0.03f), 6f, 6f, p)
    }
}
