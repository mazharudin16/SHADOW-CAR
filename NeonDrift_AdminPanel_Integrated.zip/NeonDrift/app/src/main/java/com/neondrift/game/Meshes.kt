package com.neondrift.game

import kotlin.math.*
import kotlin.random.Random

/** Mesh vertex: pos3 normal3 color4(rgb + emissive) uv2 = 12 floats. uv.x < 0 => untextured. */
class MB {
    var d = FloatArray(1 shl 16)
    var n = 0
    val verts: Int get() = n / 12

    fun v(px: Float, py: Float, pz: Float, nx: Float, ny: Float, nz: Float,
          r: Float, g: Float, b: Float, e: Float, u: Float, w: Float) {
        if (n + 12 > d.size) d = d.copyOf(d.size * 2)
        d[n++] = px; d[n++] = py; d[n++] = pz; d[n++] = nx; d[n++] = ny; d[n++] = nz
        d[n++] = r; d[n++] = g; d[n++] = b; d[n++] = e; d[n++] = u; d[n++] = w
    }

    fun quad(a: FloatArray, b: FloatArray, c: FloatArray, dd: FloatArray, nx: Float, ny: Float, nz: Float,
             col: FloatArray, u0: Float = -1f, v0: Float = -1f, u1: Float = -1f, v1: Float = -1f) {
        val r = col[0]; val g = col[1]; val bl = col[2]; val e = col[3]
        v(a[0], a[1], a[2], nx, ny, nz, r, g, bl, e, u0, v0)
        v(b[0], b[1], b[2], nx, ny, nz, r, g, bl, e, u1, v0)
        v(c[0], c[1], c[2], nx, ny, nz, r, g, bl, e, u1, v1)
        v(a[0], a[1], a[2], nx, ny, nz, r, g, bl, e, u0, v0)
        v(c[0], c[1], c[2], nx, ny, nz, r, g, bl, e, u1, v1)
        v(dd[0], dd[1], dd[2], nx, ny, nz, r, g, bl, e, u0, v1)
    }

    /** Quad whose normal is computed and flipped to point away from (hx,hy,hz). */
    fun quadAuto(a: FloatArray, b: FloatArray, c: FloatArray, dd: FloatArray, hx: Float, hy: Float, hz: Float, col: FloatArray) {
        val ux = b[0] - a[0]; val uy = b[1] - a[1]; val uz = b[2] - a[2]
        val wx = dd[0] - a[0]; val wy = dd[1] - a[1]; val wz = dd[2] - a[2]
        var nx = uy * wz - uz * wy; var ny = uz * wx - ux * wz; var nz = ux * wy - uy * wx
        val l = sqrt(nx * nx + ny * ny + nz * nz)
        if (l < 1e-6f) return
        nx /= l; ny /= l; nz /= l
        val cx = (a[0] + b[0] + c[0] + dd[0]) / 4f - hx
        val cy = (a[1] + b[1] + c[1] + dd[1]) / 4f - hy
        val cz = (a[2] + b[2] + c[2] + dd[2]) / 4f - hz
        if (nx * cx + ny * cy + nz * cz < 0f) { nx = -nx; ny = -ny; nz = -nz }
        quad(a, b, c, dd, nx, ny, nz, col)
    }

    private fun p(x: Float, y: Float, z: Float) = floatArrayOf(x, y, z)

    /** Axis-aligned box. If texU>0 the 4 side faces get window-texture UVs. */
    fun box(cx: Float, cy: Float, cz: Float, hx: Float, hy: Float, hz: Float, col: FloatArray,
            texU: Float = 0f, texV: Float = 0f, uo: Float = 0f, vo: Float = 0f, bottom: Boolean = false) {
        val x0 = cx - hx; val x1 = cx + hx; val y0 = cy - hy; val y1 = cy + hy; val z0 = cz - hz; val z1 = cz + hz
        val t = texU > 0f
        val uz = if (t) uo + 2f * hz * texU else -1f
        val ux = if (t) uo + 2f * hx * texU else -1f
        val u0 = if (t) uo else -1f
        val v0 = if (t) vo else -1f
        val v1 = if (t) vo + 2f * hy * texV else -1f
        quad(p(x1, y0, z0), p(x1, y0, z1), p(x1, y1, z1), p(x1, y1, z0), 1f, 0f, 0f, col, u0, v0, uz, v1)
        quad(p(x0, y0, z1), p(x0, y0, z0), p(x0, y1, z0), p(x0, y1, z1), -1f, 0f, 0f, col, u0, v0, uz, v1)
        quad(p(x1, y0, z1), p(x0, y0, z1), p(x0, y1, z1), p(x1, y1, z1), 0f, 0f, 1f, col, u0, v0, ux, v1)
        quad(p(x0, y0, z0), p(x1, y0, z0), p(x1, y1, z0), p(x0, y1, z0), 0f, 0f, -1f, col, u0, v0, ux, v1)
        quad(p(x0, y1, z0), p(x1, y1, z0), p(x1, y1, z1), p(x0, y1, z1), 0f, 1f, 0f, col)
        if (bottom) quad(p(x0, y0, z1), p(x1, y0, z1), p(x1, y0, z0), p(x0, y0, z0), 0f, -1f, 0f, col)
    }

    /** Horizontal quad on the ground plane. */
    fun flat(x0: Float, z0: Float, x1: Float, z1: Float, x2: Float, z2: Float, x3: Float, z3: Float, y: Float, col: FloatArray) {
        quad(p(x0, y, z0), p(x1, y, z1), p(x2, y, z2), p(x3, y, z3), 0f, 1f, 0f, col)
    }

    /** Loft through cross sections [z, halfWidth, yBottom, yTop]. */
    fun loft(s: Array<FloatArray>, col: FloatArray) {
        for (i in 0 until s.size - 1) {
            val a = s[i]; val b = s[i + 1]
            val hy = (a[2] + a[3] + b[2] + b[3]) / 4f; val hz = (a[0] + b[0]) / 2f
            quadAuto(p(-a[1], a[3], a[0]), p(a[1], a[3], a[0]), p(b[1], b[3], b[0]), p(-b[1], b[3], b[0]), 0f, hy, hz, col)
            quadAuto(p(a[1], a[2], a[0]), p(b[1], b[2], b[0]), p(b[1], b[3], b[0]), p(a[1], a[3], a[0]), 0f, hy, hz, col)
            quadAuto(p(-a[1], a[2], a[0]), p(-b[1], b[2], b[0]), p(-b[1], b[3], b[0]), p(-a[1], a[3], a[0]), 0f, hy, hz, col)
        }
        val f = s[0]; val l = s[s.size - 1]
        quad(p(-f[1], f[2], f[0]), p(f[1], f[2], f[0]), p(f[1], f[3], f[0]), p(-f[1], f[3], f[0]), 0f, 0f, -1f, col)
        quad(p(-l[1], l[2], l[0]), p(l[1], l[2], l[0]), p(l[1], l[3], l[0]), p(-l[1], l[3], l[0]), 0f, 0f, 1f, col)
    }

    /** Cylinder whose axis is the X axis. */
    fun cylX(cx: Float, cy: Float, cz: Float, rad: Float, hw: Float, seg: Int, col: FloatArray, caps: Boolean = true) {
        val r = col[0]; val g = col[1]; val b = col[2]; val e = col[3]
        for (i in 0 until seg) {
            val a0 = (2.0 * PI * i / seg).toFloat(); val a1 = (2.0 * PI * (i + 1) / seg).toFloat()
            val y0 = cos(a0); val z0 = sin(a0); val y1 = cos(a1); val z1 = sin(a1)
            val ax = cx - hw; val bx = cx + hw
            v(ax, cy + y0 * rad, cz + z0 * rad, 0f, y0, z0, r, g, b, e, -1f, -1f)
            v(bx, cy + y0 * rad, cz + z0 * rad, 0f, y0, z0, r, g, b, e, -1f, -1f)
            v(bx, cy + y1 * rad, cz + z1 * rad, 0f, y1, z1, r, g, b, e, -1f, -1f)
            v(ax, cy + y0 * rad, cz + z0 * rad, 0f, y0, z0, r, g, b, e, -1f, -1f)
            v(bx, cy + y1 * rad, cz + z1 * rad, 0f, y1, z1, r, g, b, e, -1f, -1f)
            v(ax, cy + y1 * rad, cz + z1 * rad, 0f, y1, z1, r, g, b, e, -1f, -1f)
            if (caps) for (sgn in floatArrayOf(-1f, 1f)) {
                val x = cx + sgn * hw
                v(x, cy, cz, sgn, 0f, 0f, r, g, b, e, -1f, -1f)
                v(x, cy + y0 * rad, cz + z0 * rad, sgn, 0f, 0f, r, g, b, e, -1f, -1f)
                v(x, cy + y1 * rad, cz + z1 * rad, sgn, 0f, 0f, r, g, b, e, -1f, -1f)
            }
        }
    }
}

class CarMeshes(val paint: MB, val trim: MB, val head: MB, val tail: MB, val wheel: MB)

fun col(r: Float, g: Float, b: Float, e: Float = 0f) = floatArrayOf(r, g, b, e)

fun buildCar(style: Int): CarMeshes {
    val paint = MB(); val trim = MB(); val head = MB(); val tail = MB(); val wheel = MB()
    val white = col(1f, 1f, 1f)
    val glass = col(0.03f, 0.05f, 0.08f)
    val dark = col(0.02f, 0.02f, 0.025f)
    val body: Array<FloatArray>; val cabin: Array<FloatArray>; val roof: Array<FloatArray>
    val zf: Float; val zr: Float
    when (style) {
        1 -> {
            body = arrayOf(floatArrayOf(-2.30f, .84f, .34f, .95f), floatArrayOf(-1.80f, .95f, .32f, 1.05f), floatArrayOf(-0.50f, .96f, .32f, 1.05f),
                floatArrayOf(0.50f, .96f, .32f, 1.04f), floatArrayOf(1.50f, .95f, .32f, 1.00f), floatArrayOf(2.15f, .90f, .34f, .80f), floatArrayOf(2.40f, .82f, .38f, .62f))
            cabin = arrayOf(floatArrayOf(-1.00f, .76f, 1.02f, 1.10f), floatArrayOf(-0.55f, .78f, 1.02f, 1.50f), floatArrayOf(0.20f, .78f, 1.02f, 1.50f), floatArrayOf(0.60f, .76f, 1.02f, 1.12f))
            roof = arrayOf(floatArrayOf(-0.5f, .66f, 1.46f, 1.52f), floatArrayOf(0.15f, .66f, 1.46f, 1.52f))
            zf = 2.4f; zr = -2.3f
        }
        2 -> {
            body = arrayOf(floatArrayOf(-1.95f, .82f, .32f, .98f), floatArrayOf(-1.60f, .90f, .30f, 1.08f), floatArrayOf(-0.60f, .92f, .30f, 1.06f),
                floatArrayOf(0.50f, .92f, .30f, .98f), floatArrayOf(1.30f, .90f, .30f, .80f), floatArrayOf(1.85f, .84f, .32f, .60f), floatArrayOf(2.05f, .78f, .36f, .52f))
            cabin = arrayOf(floatArrayOf(-1.55f, .70f, 1.02f, 1.12f), floatArrayOf(-1.00f, .74f, 1.02f, 1.50f), floatArrayOf(0.05f, .74f, 1.02f, 1.50f), floatArrayOf(0.75f, .72f, 1.02f, 1.15f))
            roof = arrayOf(floatArrayOf(-0.95f, .64f, 1.46f, 1.52f), floatArrayOf(0.0f, .64f, 1.46f, 1.52f))
            zf = 2.05f; zr = -1.95f
        }
        else -> {
            body = arrayOf(floatArrayOf(-2.15f, .80f, .32f, .86f), floatArrayOf(-1.75f, .91f, .30f, 1.00f), floatArrayOf(-0.90f, .93f, .30f, 1.02f),
                floatArrayOf(0.30f, .93f, .30f, .98f), floatArrayOf(1.25f, .92f, .30f, .86f), floatArrayOf(1.95f, .86f, .32f, .62f), floatArrayOf(2.20f, .78f, .36f, .52f))
            cabin = arrayOf(floatArrayOf(-1.30f, .70f, .98f, 1.02f), floatArrayOf(-0.55f, .74f, .98f, 1.42f), floatArrayOf(0.35f, .74f, .98f, 1.42f), floatArrayOf(0.95f, .72f, .98f, 1.10f))
            roof = arrayOf(floatArrayOf(-0.60f, .62f, 1.40f, 1.45f), floatArrayOf(0.30f, .62f, 1.40f, 1.45f))
            zf = 2.2f; zr = -2.15f
        }
    }
    paint.loft(body, white)
    paint.loft(roof, white)
    trim.loft(cabin, glass)
    trim.box(0f, 0.29f, (zf + zr) / 2f, 0.8f, 0.02f, (zf - zr) / 2f - 0.1f, dark)
    trim.box(0f, 0.30f, zf - 0.1f, 0.82f, 0.03f, 0.25f, dark)
    trim.box(0f, 0.32f, zr + 0.1f, 0.70f, 0.05f, 0.20f, dark)
    trim.box(0.94f, 0.34f, 0f, 0.03f, 0.08f, 1.0f, dark)
    trim.box(-0.94f, 0.34f, 0f, 0.03f, 0.08f, 1.0f, dark)
    trim.box(0f, 0.50f, zf - 0.03f, 0.50f, 0.07f, 0.03f, dark)
    trim.box(0.98f, 1.02f, 0.55f, 0.10f, 0.05f, 0.06f, dark)
    trim.box(-0.98f, 1.02f, 0.55f, 0.10f, 0.05f, 0.06f, dark)
    val metal = col(0.55f, 0.57f, 0.6f)
    trim.box(0.45f, 0.38f, zr - 0.02f, 0.07f, 0.07f, 0.04f, metal)
    trim.box(-0.45f, 0.38f, zr - 0.02f, 0.07f, 0.07f, 0.04f, metal)
    if (style == 1) {
        trim.box(0f, 1.05f, zr + 0.1f, 0.8f, 0.03f, 0.12f, dark)
        trim.box(0f, 1.07f, 1.2f, 0.28f, 0.03f, 0.5f, dark)
    } else {
        val wy = if (style == 2) 1.30f else 1.22f
        trim.box(0f, wy, zr + 0.2f, 0.88f, 0.025f, 0.22f, dark)
        trim.box(0.55f, wy - 0.13f, zr + 0.2f, 0.03f, 0.13f, 0.05f, dark)
        trim.box(-0.55f, wy - 0.13f, zr + 0.2f, 0.03f, 0.13f, 0.05f, dark)
    }
    val hy = if (style == 1) 0.60f else 0.55f
    head.box(0.62f, hy, zf - 0.08f, 0.20f, 0.05f, 0.05f, col(0.9f, 0.95f, 1f, 1f))
    head.box(-0.62f, hy, zf - 0.08f, 0.20f, 0.05f, 0.05f, col(0.9f, 0.95f, 1f, 1f))
    tail.box(0f, 0.82f, zr + 0.02f, 0.72f, 0.05f, 0.03f, col(1f, 0.05f, 0.05f, 1f))

    // wheel (axis = X), 0.34m radius
    wheel.cylX(0f, 0f, 0f, 0.34f, 0.13f, 14, col(0.025f, 0.025f, 0.03f))
    wheel.cylX(0f, 0f, 0f, 0.23f, 0.135f, 14, col(0.62f, 0.64f, 0.68f, 0.10f))
    for (k in 0 until 5) {
        val a = (2.0 * PI * k / 5).toFloat()
        for (sgn in floatArrayOf(-1f, 1f)) {
            val y = cos(a) * 0.12f; val z = sin(a) * 0.12f
            wheel.box(sgn * 0.138f, y, z, 0.01f, 0.025f + abs(sin(a)) * 0.035f, 0.025f + abs(cos(a)) * 0.035f, col(0.12f, 0.12f, 0.14f))
        }
    }
    return CarMeshes(paint, trim, head, tail, wheel)
}

/** Static city: ground, road, curbs, lamps, buildings, neon. Also fills glow sprites and light-pool decals. */
fun buildWorld(w: World, glows: ArrayList<FloatArray>, pools: ArrayList<Float>): MB {
    val mb = MB()
    val rnd = Random(5)
    val ground = col(0.020f, 0.022f, 0.032f)
    mb.flat(-2500f, -2500f, 2500f, -2500f, 2500f, 2500f, -2500f, 2500f, 0f, ground)
    // central plaza
    val plaza = 85
    val seg = 40
    for (i in 0 until seg) {
        val a0 = (2.0 * PI * i / seg).toFloat(); val a1 = (2.0 * PI * (i + 1) / seg).toFloat()
        for ((rA, rB, c) in arrayOf(Triple(0f, plaza.toFloat(), col(0.06f, 0.06f, 0.075f)), Triple(plaza - 3f, plaza - 2.4f, col(0.9f, 0.9f, 1f, 0.3f)),
            Triple(46f, 46.6f, col(0.9f, 0.9f, 1f, 0.3f)), Triple(20f, 20.6f, col(1f, 0.2f, 0.9f, 0.6f)))) {
            mb.flat(sin(a0) * rA, cos(a0) * rA, sin(a0) * rB, cos(a0) * rB, sin(a1) * rB, cos(a1) * rB, sin(a1) * rA, cos(a1) * rA, if (rA > 0f) 0.07f else 0.06f, c)
        }
    }
    val n = w.n; val hw = w.roadW / 2f
    for (i in 0 until n) {
        val j = (i + 1) % n
        val lx0 = w.dirZ(i); val lz0 = -w.dirX(i)
        val lx1 = w.dirZ(j); val lz1 = -w.dirX(j)
        val x0 = w.tx[i]; val z0 = w.tz[i]; val x1 = w.tx[j]; val z1 = w.tz[j]
        val shade = 0.065f + rnd.nextFloat() * 0.012f
        val asph = col(shade, shade, shade + 0.015f)
        fun strip(o0: Float, o1: Float, y: Float, c: FloatArray) {
            mb.flat(x0 + lx0 * o0, z0 + lz0 * o0, x0 + lx0 * o1, z0 + lz0 * o1,
                x1 + lx1 * o1, z1 + lz1 * o1, x1 + lx1 * o0, z1 + lz1 * o0, y, c)
        }
        strip(-hw, hw, 0.07f, asph)
        val edge = col(0.85f, 0.85f, 0.9f, 0.15f)
        strip(hw - 1.1f, hw - 0.85f, 0.085f, edge); strip(-hw + 0.85f, -hw + 1.1f, 0.085f, edge)
        if (i % 4 < 2) strip(-0.12f, 0.12f, 0.085f, col(0.95f, 0.8f, 0.2f, 0.2f))
        val cb = if ((i / 2) % 2 == 0) col(0.9f, 0.1f, 0.1f, 0.1f) else col(0.9f, 0.9f, 0.92f, 0.1f)
        strip(hw, hw + 0.8f, 0.09f, cb); strip(-hw - 0.8f, -hw, 0.09f, cb)
        val sw = col(0.11f, 0.11f, 0.13f)
        strip(hw + 0.8f, hw + 6f, 0.08f, sw); strip(-hw - 6f, -hw - 0.8f, 0.08f, sw)
        // lamps
        if (i % 14 == 0) {
            val side = if ((i / 14) % 2 == 0) 1f else -1f
            val off = side * (hw + 2.2f)
            val px = x0 + lx0 * off; val pz = z0 + lz0 * off
            mb.box(px, 3.6f, pz, 0.09f, 3.6f, 0.09f, col(0.08f, 0.08f, 0.1f))
            mb.box(px - lx0 * side * 1.0f, 7.25f, pz - lz0 * side * 1.0f, 0.5f, 0.07f, 0.5f, col(1f, 0.85f, 0.55f, 1f))
            glows.add(floatArrayOf(px - lx0 * side, 7.1f, pz - lz0 * side, 5.5f, 1f, 0.75f, 0.4f))
            val cxp = px - lx0 * side * 5f; val czp = pz - lz0 * side * 5f
            val r = 11f
            pools.add(cxp); pools.add(czp); pools.add(r)
        }
    }
    // buildings
    val neon = arrayOf(floatArrayOf(1f, 0.15f, 0.85f), floatArrayOf(0f, 0.9f, 1f), floatArrayOf(1f, 0.5f, 0.1f), floatArrayOf(0.5f, 1f, 0.2f), floatArrayOf(0.6f, 0.3f, 1f))
    for (b in w.buildings) {
        val t = 0.035f + rnd.nextFloat() * 0.04f
        val c = col(t, t, t + 0.025f + rnd.nextFloat() * 0.02f)
        mb.box(b.x, b.h / 2f, b.z, b.hx, b.h / 2f, b.hz, c, 1f / 25.6f, 1f / 28.8f, rnd.nextFloat(), rnd.nextFloat())
        mb.box(b.x, b.h + 0.4f, b.z, b.hx * 0.6f, 0.4f, b.hz * 0.6f, col(0.03f, 0.03f, 0.04f))
        if (rnd.nextFloat() < 0.8f) {
            val nc = neon[rnd.nextInt(neon.size)]
            val sh = 6f + rnd.nextFloat() * 10f
            val sy = 8f + rnd.nextFloat() * (b.h * 0.6f)
            val ec = col(nc[0], nc[1], nc[2], 1f)
            val faceX = rnd.nextBoolean()
            if (faceX) {
                val sx = b.x + (if (rnd.nextBoolean()) b.hx + 0.15f else -b.hx - 0.15f)
                mb.box(sx, sy, b.z + (rnd.nextFloat() - 0.5f) * b.hz, 0.12f, sh / 2f, 0.7f, ec)
                glows.add(floatArrayOf(sx, sy, b.z, 9f, nc[0], nc[1], nc[2]))
            } else {
                val sz = b.z + (if (rnd.nextBoolean()) b.hz + 0.15f else -b.hz - 0.15f)
                mb.box(b.x + (rnd.nextFloat() - 0.5f) * b.hx, sy, sz, 0.7f, sh / 2f, 0.12f, ec)
                glows.add(floatArrayOf(b.x, sy, sz, 9f, nc[0], nc[1], nc[2]))
            }
        }
        if (b.h > 60f) glows.add(floatArrayOf(b.x, b.h + 1.2f, b.z, 4f, 1f, 0.1f, 0.1f))
    }
    return mb
}
