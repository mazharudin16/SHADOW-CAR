package com.neondrift.game

import kotlin.math.*
import kotlin.random.Random

class Building(val x: Float, val z: Float, val hx: Float, val hz: Float, val h: Float)

class World {
    val roadW = 18f
    val tx: FloatArray
    val tz: FloatArray
    val buildings = ArrayList<Building>()
    val n: Int get() = tx.size

    init {
        val c = arrayOf(
            floatArrayOf(0f, -300f), floatArrayOf(160f, -320f), floatArrayOf(300f, -230f), floatArrayOf(340f, -80f),
            floatArrayOf(280f, 40f), floatArrayOf(150f, 60f), floatArrayOf(60f, 140f), floatArrayOf(120f, 260f),
            floatArrayOf(60f, 360f), floatArrayOf(-110f, 350f), floatArrayOf(-200f, 250f), floatArrayOf(-170f, 130f),
            floatArrayOf(-300f, 70f), floatArrayOf(-340f, -60f), floatArrayOf(-250f, -170f), floatArrayOf(-120f, -230f)
        )
        val m = c.size
        val dx = ArrayList<Float>(); val dz = ArrayList<Float>()
        for (i in 0 until m) {
            val p0 = c[(i - 1 + m) % m]; val p1 = c[i]; val p2 = c[(i + 1) % m]; val p3 = c[(i + 2) % m]
            for (s in 0 until 40) {
                val t = s / 40f
                val t2 = t * t; val t3 = t2 * t
                for (k in 0..1) {
                    val v = 0.5f * (2f * p1[k] + (-p0[k] + p2[k]) * t + (2f * p0[k] - 5f * p1[k] + 4f * p2[k] - p3[k]) * t2 +
                        (-p0[k] + 3f * p1[k] - 3f * p2[k] + p3[k]) * t3)
                    if (k == 0) dx.add(v) else dz.add(v)
                }
            }
        }
        val d = dx.size
        val cum = FloatArray(d + 1)
        for (i in 0 until d) {
            val j = (i + 1) % d
            cum[i + 1] = cum[i] + hypot(dx[j] - dx[i], dz[j] - dz[i])
        }
        val total = cum[d]
        val cnt = (total / 3f).roundToInt()
        val ox = FloatArray(cnt); val oz = FloatArray(cnt)
        var j = 0
        for (k in 0 until cnt) {
            val tg = k * total / cnt
            while (cum[j + 1] < tg) j++
            val a = j; val b = (j + 1) % d
            val f = (tg - cum[a]) / (cum[a + 1] - cum[a])
            ox[k] = dx[a] + (dx[b] - dx[a]) * f
            oz[k] = dz[a] + (dz[b] - dz[a]) * f
        }
        tx = ox; tz = oz
        genBuildings()
    }

    fun dirX(i: Int): Float { val a = (i - 1 + n) % n; val b = (i + 1) % n; val l = hypot(tx[b] - tx[a], tz[b] - tz[a]); return (tx[b] - tx[a]) / l }
    fun dirZ(i: Int): Float { val a = (i - 1 + n) % n; val b = (i + 1) % n; val l = hypot(tx[b] - tx[a], tz[b] - tz[a]); return (tz[b] - tz[a]) / l }
    fun startPsi(i: Int = 0): Float = atan2(dirX(i), dirZ(i))

    fun nearest(x: Float, z: Float): Int {
        var best = 0; var bd = Float.MAX_VALUE
        for (i in 0 until n) {
            val d = (tx[i] - x) * (tx[i] - x) + (tz[i] - z) * (tz[i] - z)
            if (d < bd) { bd = d; best = i }
        }
        return best
    }

    private fun trackDist(x: Float, z: Float): Float {
        var bd = Float.MAX_VALUE
        var i = 0
        while (i < n) {
            val d = (tx[i] - x) * (tx[i] - x) + (tz[i] - z) * (tz[i] - z)
            if (d < bd) bd = d
            i += 2
        }
        return sqrt(bd)
    }

    private fun genBuildings() {
        val rnd = Random(11)
        var tries = 0
        while (tries < 3500 && buildings.size < 340) {
            tries++
            val x = rnd.nextFloat() * 1100f - 550f
            val z = rnd.nextFloat() * 1100f - 550f
            if (hypot(x, z) < 85f) continue // central drift plaza stays empty
            val hx = 7f + rnd.nextFloat() * 14f
            val hz = 7f + rnd.nextFloat() * 14f
            val clear = roadW / 2f + 24f + max(hx, hz) * 1.3f
            if (trackDist(x, z) < clear) continue
            var ok = true
            for (o in buildings) {
                if (abs(o.x - x) < o.hx + hx + 6f && abs(o.z - z) < o.hz + hz + 6f) { ok = false; break }
            }
            if (!ok) continue
            val dc = hypot(x, z)
            val h = 22f + rnd.nextFloat() * 50f + (if (dc < 380f) rnd.nextFloat() * 60f else 0f)
            buildings.add(Building(x, z, hx, hz, h))
        }
    }

    /** Returns impact speed (m/s) if the car hit something, else 0. */
    fun collide(c: CarPhysics): Float {
        var impact = 0f
        val sn = sin(c.psi); val cs = cos(c.psi)
        val rad = 1.0f
        for (off in OFFS) {
            val px = c.x + sn * off; val pz = c.z + cs * off
            for (bd in buildings) {
                if (abs(px - bd.x) > bd.hx + 3f || abs(pz - bd.z) > bd.hz + 3f) continue
                val cx = px.coerceIn(bd.x - bd.hx, bd.x + bd.hx)
                val cz = pz.coerceIn(bd.z - bd.hz, bd.z + bd.hz)
                var ddx = px - cx; var ddz = pz - cz
                var d2 = ddx * ddx + ddz * ddz
                if (d2 >= rad * rad) continue
                var nx: Float; var nz: Float; var pen: Float
                if (d2 < 1e-6f) {
                    val l = px - (bd.x - bd.hx); val r = (bd.x + bd.hx) - px
                    val t = pz - (bd.z - bd.hz); val bt = (bd.z + bd.hz) - pz
                    val m = min(min(l, r), min(t, bt))
                    nx = 0f; nz = 0f
                    if (m == l) nx = -1f else if (m == r) nx = 1f else if (m == t) nz = -1f else nz = 1f
                    pen = m + rad
                } else {
                    val dd = sqrt(d2); nx = ddx / dd; nz = ddz / dd; pen = rad - dd
                }
                c.x += nx * pen; c.z += nz * pen
                var vx = c.u * sn + c.v * cs
                var vz = c.u * cs - c.v * sn
                val vn = vx * nx + vz * nz
                if (vn < 0f) {
                    impact = max(impact, -vn)
                    vx -= 1.2f * vn * nx; vz -= 1.2f * vn * nz
                    vx *= 0.97f; vz *= 0.97f
                    c.u = vx * sn + vz * cs
                    c.v = vx * cs - vz * sn
                    c.r *= 0.75f
                }
            }
        }
        val dist = hypot(c.x, c.z)
        if (dist > 720f) { c.x *= 720f / dist; c.z *= 720f / dist; c.u *= 0.5f; c.v *= 0.5f }
        return impact
    }

    companion object { private val OFFS = floatArrayOf(-1.5f, 0f, 1.5f) }
}
